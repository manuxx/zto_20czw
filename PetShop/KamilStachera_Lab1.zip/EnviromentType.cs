namespace Training.DomainClasses
{
    public enum EnviromentType
    {
        Home, Cage, Terrarium, Aquarium
    }
}