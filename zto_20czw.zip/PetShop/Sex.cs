namespace Training.DomainClasses
{
    public enum Sex
    {
        Male, Female, Androgyne
    }
}